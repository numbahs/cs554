import axios from 'axios';

const Client_ID = '5e4eda51f0b9462aa8932a242710da6d',
  Client_Secret = 'e33eaf364b4a4fa099ec69fe058f65e1';

const b64key = new Buffer(`${Client_ID}:${Client_Secret}`).toString('base64');

const auth = async () => {
  const { data } = await axios.post(
    'https://cs-554-spotify-proxy.herokuapp.com/api/token',
    'grant_type=client_credentials',
    {
      headers: {
        Authorization: `Basic ${b64key}`
      }
    }
  );
  return data;
};

const searchForSong = async (query, token) => {
  const { data } = await axios.get(
    'https://cs-554-spotify-proxy.herokuapp.com/v1/search',
    {
      params: {
        q: query,
        type: 'track',
        market: 'US'
      },
      headers: {
        Authorization: `Bearer ${token}`
      }
    }
  );
  return data;
};

export {
  auth,
  searchForSong
}